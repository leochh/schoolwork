/*
 * Audio Bypass Project
 */

#include <usbstk5515.h>
#include <usbstk5515_i2c.h>
#include <AIC_func.h>
#include <stdio.h>
#include <Dsplib.h>

#define TAPS	49
//#define BLOCK_SIZE	32

Int16 LP[TAPS] = {
	#include "lpf.dat"
};
Int16 LP2[TAPS] = {
	#include "lpf.dat"
};
Int16 dbuffer_left[TAPS+2] = {0};
Int16 dbuffer_right[TAPS+2] = {0};
 
void main(void)
{
	Int16 x_right[1], x_left[1]; //AIC inputs
	Int16 r_right[1], r_left[1]; //AIC outputs
	Uint16 i=0;
	Uint16 j=0;

	USBSTK5515_init(); 	//Initializing the Processor
	AIC_init(); 		//Initializing the Audio Codec
	while(1)
	{
		AIC_read2(&x_right[i], &x_left[i]);
//		i++;
//		if (i==BLOCK_SIZE)
//		{
			fir(&x_right[0],&LP[0],&r_right[0],&dbuffer_right[0],1,TAPS);
	//		r_right[0]=x_right[0];
			fir(&x_left[0],&LP2[0],&r_left[0],&dbuffer_left[0],1,TAPS);
	//		r_left[0]=x_left[0];
//		}
		AIC_write2(r_right[j],r_left[j]);
//		j++;
	}
}
